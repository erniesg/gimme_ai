# gimme_ai/__init__.py
"""Secure API gateway management for AI services."""

__version__ = "0.1.0"
